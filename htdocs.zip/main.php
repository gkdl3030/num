<html>
    <head><title>번호 관리</title></head>
    <body>
        <center>
            <br><h2> ♠♠번호 관리 프로젝트♠♠</h2><hr><br>
    ~~ 프로그램 순서는 다음과 같습니다. ~~<br><br>
    <form name=f1 method=post action="mem_tbl.php">
    <table width=400 border=0 bordercolor=#000000
    cellspacing=1 height=180 bgcolor=#FFFFCC>
    <tr><td width=5%></td>
    <td><br><b>&nbsp;&nbsp; 1.테이블 생성<br><br>
    &nbsp;&nbsp; 2. 번호 입력 화면에서 정보 입력<br><br>
    &nbsp;&nbsp; 3. num_db 데이터베이스 저장<br><br>
    &nbsp;&nbsp; 4. 번호 현황 출력</b><br><br>
    </td><td width=5%></td>
    </tr>
    </table><br>
    아래 버튼을 누르면 [ numtbl ] 테이블이 생성됩니다.<br><br>
    <input type="submit" value="◀ 테이블 생성하기 ▶ ">
</form>
</center>
</body>
</html>